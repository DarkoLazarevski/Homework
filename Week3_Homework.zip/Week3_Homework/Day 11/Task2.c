#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define STACK_SIZE 100

typedef struct {
    double data[STACK_SIZE];
    int top;
} Stack;

void initStack(Stack *stack) {
    stack->top = -1;
}

int isFull(Stack *stack) {
    return stack->top == STACK_SIZE - 1;
}

int isEmpty(Stack *stack) {
    return stack->top == -1;
}

void push(Stack *stack, double value) {
    if (!isFull(stack)) {
        stack->top++;
        stack->data[stack->top] = value;
    } else {
        printf("Stack is full.\n");
    }
}

double pop(Stack *stack) {
    if (!isEmpty(stack)) {
        double value = stack->data[stack->top];
        stack->top--;
        return value;
    } else {
        printf("Stack is empty.\n");
        return 0;
    }
}

int main() {
    Stack stack;
    initStack(&stack);
    
    char token[10];
    
    while (scanf("%s", token) == 1) {
        if (isdigit(token[0]) || (token[0] == '-' && isdigit(token[1]))) {
            push(&stack, atof(token));
        } else if (token[0] == '+') {
            double a = pop(&stack);
            double b = pop(&stack);
            push(&stack, a + b);
        } else if (token[0] == '*') {
            double a = pop(&stack);
            double b = pop(&stack);
            push(&stack, a * b);
        } else if (token[0] == '-') {
            double a = pop(&stack);
            double b = pop(&stack);
            push(&stack, b - a);
        }
    }
    
    printf("%.2lf\n", pop(&stack));
    
    return 0;
}
