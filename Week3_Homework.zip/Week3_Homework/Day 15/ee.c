#include <stdio.h>

int evennumbers(int arr[]);
int is_prime(int num);
int filter_and_map(int arr[], int num);

int main(){
int arr[10]={2,4,6,8,10,11,13,17,21,23};
int size = sizeof(arr) / sizeof(arr[0]);
int num;


 printf("Prime square numbers in the Array: ");
    for (int i = 0; i < size; ++i) {
        if (is_prime(arr[i])) {
            printf("%d ", arr[i]*arr[i]);
        }
    }

filter_and_map(arr,  num);


}
int evennumbers(int arr[]){
printf("\nEven numbers: ");
    for(int i=0;i<10;i++){
        if(arr[i]%2==0){
            printf("%d, ",arr[i]);
        }
    }
    printf("\n");
}

int is_prime(int num) {
    if (num < 2) {
        return 0;
    }
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            return 0;
        }
    }
    return 1;
}
int filter_and_map(int arr[], int num){
    int even=evennumbers(arr);
    int prime=is_prime(num);

}