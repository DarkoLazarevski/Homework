#include <stdio.h>

int is_prime(int num) {
    if (num < 2) {
        return 0;
    }
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int size = sizeof(numbers) / sizeof(numbers[0]);

    printf("Prime Numbers in the Array: ");
    for (int i = 0; i < size; ++i) {
        if (is_prime(numbers[i])) {
            printf("%d ", numbers[i]);
        }
    }
    printf("\n");

    return 0;
}
