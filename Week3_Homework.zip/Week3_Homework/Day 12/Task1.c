#include <stdio.h>
#include <stdarg.h>
#include <time.h>

int printf_time(const char *format, ...) {
    time_t current_time;
    struct tm *time_info;
    char time_string[22];  // [dd.mm.yyyy - hh:mm:ss]

    time(&current_time);
    time_info = localtime(&current_time);

    strftime(time_string, sizeof(time_string), "[%d.%m.%Y - %H:%M:%S]", time_info);
    printf("%s ", time_string);

    va_list args;
    va_start(args, format);
    int result = vprintf(format, args);
    va_end(args);

    return result;
}

int main() {
    printf_time("%d %d", 10, 20);
    return 0;
}
