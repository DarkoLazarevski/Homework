#include <stdio.h>
#include <stdarg.h>

int my_printf(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);

    int printed_chars = 0;
    char ch;

    while ((ch = *fmt++) != '\0') {
        if (ch == '%') {
            ch = *fmt++;
            switch (ch) {
                case 'd': {
                    int num = va_arg(args, int);
                    printed_chars += printf("%d", num);
                    break;
                }
                case 'f': {
                    double num = va_arg(args, double);
                    printed_chars += printf("%f", num);
                    break;
                }
                case 'c': {
                    char c = va_arg(args, int);  // Characters are promoted to int
                    printed_chars += putchar(c);
                    break;
                }
                default:
                    printed_chars += putchar('%');
                    printed_chars += putchar(ch);
            }
        } else {
            printed_chars += putchar(ch);
        }
    }

    va_end(args);
    return printed_chars;
}

int main() {
    int a = 42;
    double b = 3.14;
    char c = 'X';

    int chars_printed = my_printf("Integer: %d, Float: %f, Char: %c\n", a, b, c);
    printf("Total characters printed: %d\n", chars_printed);

    return 0;
}
