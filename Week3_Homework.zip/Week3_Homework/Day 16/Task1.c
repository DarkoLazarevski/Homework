#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void process_A(int read_fd, int write_fd) {
    close(write_fd);

    int array[10];
    read(read_fd, array, sizeof(array));

    int sum = 0;
    for (int i = 0; i < 10; i++) {
        if (array[i] % 2 == 0) {
            sum += array[i];
        }
    }

    close(read_fd);
    write(write_fd, &sum, sizeof(sum));
    close(write_fd);
    exit(0);
}

void process_B(int read_fd, int write_fd) {
    close(read_fd);

    int sum;
    read(write_fd, &sum, sizeof(sum));

    int square = sum * sum;

    close(write_fd);
    write(read_fd, &square, sizeof(square));
    close(read_fd);
    exit(0);
}

int main() {
    int pipe_A[2];
    int pipe_B[2];
    int pipe_C[2];

    if (pipe(pipe_A) == -1 || pipe(pipe_B) == -1 || pipe(pipe_C) == -1) {
        perror("Pipe creation failed");
        return 1;
    }

    int pid_A = fork();

    if (pid_A == 0) {
        // Process A
        close(pipe_A[1]);
        close(pipe_B[0]);
        close(pipe_C[0]);
        close(pipe_C[1]);
        process_A(pipe_A[0], pipe_B[1]);
    }

    int pid_B = fork();

    if (pid_B == 0) {
        // Process B
        close(pipe_A[0]);
        close(pipe_A[1]);
        close(pipe_B[1]);
        close(pipe_C[0]);
        process_B(pipe_B[0], pipe_C[1]);
    }

    // Parent process
    close(pipe_A[0]);
    close(pipe_B[0]);
    close(pipe_B[1]);
    close(pipe_C[1]);

    int array[10];
    for (int i = 0; i < 10; i++) {
        array[i] = rand() % 100 + 1;
    }

    write(pipe_A[1], array, sizeof(array));
    close(pipe_A[1]);

    int square;
    read(pipe_C[0], &square, sizeof(square));
    close(pipe_C[0]);

    printf("Sum of Squares: %d\n", square);

    return 0;
}
