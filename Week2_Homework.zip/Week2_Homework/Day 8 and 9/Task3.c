#include <stdio.h>
#include <stdint.h>
#include <math.h>

typedef struct Point {
    double x;
    double y;
    double z;
} Point;

typedef struct Human {
    double weight_kg;
    uint16_t height_cm;
} Human;

int compareUint64(const void *a, const void *b) {
    return (*(uint64_t *)a > *(uint64_t *)b) - (*(uint64_t *)a < *(uint64_t *)b);
}

int comparePointDistance(const void *a, const void *b) {
    Point *pointA = (Point *)a;
    Point *pointB = (Point *)b;
    double distanceA = sqrt(pointA->x * pointA->x + pointA->y * pointA->y + pointA->z * pointA->z);
    double distanceB = sqrt(pointB->x * pointB->x + pointB->y * pointB->y + pointB->z * pointB->z);
    return (distanceA > distanceB) - (distanceA < distanceB);
}

int compareHumanBMI(const void *a, const void *b) {
    Human *humanA = (Human *)a;
    Human *humanB = (Human *)b;
    double bmiA = humanA->weight_kg / ((humanA->height_cm / 100.0) * (humanA->height_cm / 100.0));
    double bmiB = humanB->weight_kg / ((humanB->height_cm / 100.0) * (humanB->height_cm / 100.0));
    return (bmiA > bmiB) - (bmiA < bmiB);
}
int countBits(uint32_t num) {
    int count = 0;
    while (num) {
        count += num & 1;
        num >>= 1;
    }
    return count;
}
int compareFloatBits(const void *a, const void *b) {
    float floatA = *(float *)a;
    float floatB = *(float *)b;
    int bitsCountA = countBits(*(uint32_t *)&floatA);
    int bitsCountB = countBits(*(uint32_t *)&floatB);
    return (bitsCountA > bitsCountB) - (bitsCountA < bitsCountB);
}
void *findMax(void *arr, size_t numElements, size_t elemSize, int (*cmp)(const void *, const void *)) {
    if (numElements == 0) return NULL;

    void *maxElement = arr;
    for (size_t i = 1; i < numElements; i++) {
        if (cmp(arr + i * elemSize, maxElement) > 0) {
            maxElement = arr + i * elemSize;
        }
    }
    return maxElement;
}

int main() {
    uint64_t uint64Arr[] = {10, 5, 25, 7, 100};
    size_t uint64ArrSize = sizeof(uint64Arr) / sizeof(uint64Arr[0]);
    uint64_t *maxUint64 = (uint64_t *)findMax(uint64Arr, uint64ArrSize, sizeof(uint64Arr[0]), compareUint64);
    printf("Max uint64: %lu\n", *maxUint64);

    Point pointArr[] = {{1.0, 2.0, 3.0}, {0.0, 0.0, 5.0}, {2.0, 2.0, 2.0}};
    size_t pointArrSize = sizeof(pointArr) / sizeof(pointArr[0]);
    Point *maxPoint = (Point *)findMax(pointArr, pointArrSize, sizeof(pointArr[0]), comparePointDistance);
    printf("Max point distance: (%lf, %lf, %lf)\n", maxPoint->x, maxPoint->y, maxPoint->z);

    Human humanArr[] = {{70.0, 170}, {65.0, 160}, {80.0, 180}};
    size_t humanArrSize = sizeof(humanArr) / sizeof(humanArr[0]);
    Human *minBMIHuman = (Human *)findMax(humanArr, humanArrSize, sizeof(humanArr[0]), compareHumanBMI);
    printf("Min BMI human: Weight: %lf kg, Height: %u cm\n", minBMIHuman->weight_kg, minBMIHuman->height_cm);

    float floatArr[] = {0.1f, 3.14f, 2.718f, 6.022f, 1.618f};
    size_t floatArrSize = sizeof(floatArr) / sizeof(floatArr[0]);
    float *maxBitsFloat = (float *)findMax(floatArr, floatArrSize, sizeof(floatArr[0]), compareFloatBits);
    printf("Max bits float: %f\n", *maxBitsFloat);

    return 0;
}
