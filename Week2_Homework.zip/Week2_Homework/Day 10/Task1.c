#include <stdio.h>
#include <stdint.h>

void swapBytes(uint16_t *word) {
    uint8_t *byteArray = (uint8_t *)word;
    
    uint8_t temp = byteArray[0];
    byteArray[0] = byteArray[1];
    byteArray[1] = temp;
}

int main() {
    uint16_t num = 0xABCD;
    
    printf("Before swapping: 0x%X\n", num);
    
    swapBytes(&num);
    
    printf("After swapping: 0x%X\n", num);
    
    return 0;
}
