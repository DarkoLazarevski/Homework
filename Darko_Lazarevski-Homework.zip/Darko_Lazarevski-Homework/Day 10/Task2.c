#include <stdio.h>
#include <stdint.h>
#include <string.h>

void printDoubleBits(double num) {
    uint64_t *ptr = (uint64_t *)&num;
    
    for (int i = 63; i >= 0; i--) {
        uint64_t bit = (*ptr >> i) & 1;
        printf("%lu", bit);
        
        if (i == 63 || i == 52) {
            printf(" ");
        }
    }
    printf("\n");
}

void printDoubleComponents(double num) {
    uint64_t *ptr = (uint64_t *)&num;
    
    uint64_t sign = (*ptr >> 63) & 1;
    int64_t exponent = (*ptr >> 52) & 0x7FF;
    uint64_t mantissa = *ptr & 0xFFFFFFFFFFFFF;
    
    printf("Sign: %lu\n", sign);
    printf("Exponent: %ld\n", (int64_t)exponent - 1023);
    printf("Mantissa: %lu\n", mantissa);
}

int main() {
    double num = -123.456;

    printf("Double bits: ");
    printDoubleBits(num);

    printf("Components:\n");
    printDoubleComponents(num);

    return 0;
}
