#include <stdio.h>
#include <string.h>

int compare_int(const void* a, const void* b) {
    const int* int_a = (const int*)a;
    const int* int_b = (const int*)b;

    if (*int_a == *int_b) return 0;
    return (*int_a > *int_b) ? -1 : 1;
}

int compare_double(const void* a, const void* b) {
    const double* double_a = (const double*)a;
    const double* double_b = (const double*)b;

    if (*double_a == *double_b) return 0;
    return (*double_a > *double_b) ? -1 : 1;
}

void* findMax(void* arr, size_t n, size_t elem_s, int (*cmp)(const void*, const void*)) {
    if (n == 0) return NULL;
    void* max_elem = arr;

    for (size_t i = 1; i < n; ++i) {
        if (cmp(arr + i * elem_s, max_elem) > 0) {
            max_elem = arr + i * elem_s;
        }
    }

    return max_elem;
}

int main() {
    int int_array[] = {1, 5, 3, 9, 2};
    double double_array[] = {1.1, 5.5, 3.3, 9.9, 2.2};

    size_t int_size = sizeof(int);
    size_t double_size = sizeof(double);

    int* max_int = findMax(int_array, sizeof(int_array) / int_size, int_size, compare_int);
    double* max_double = findMax(double_array, sizeof(double_array) / double_size, double_size, compare_double);

    printf("Max int: %d\n", *max_int);
    printf("Max double: %lf\n", *max_double);

    return 0;
}
