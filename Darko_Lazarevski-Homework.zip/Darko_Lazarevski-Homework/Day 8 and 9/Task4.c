#include <stdio.h>
#include <stdint.h>

int clearBits(uint32_t* maskArr, size_t nitems, size_t bit_index) {
    if (bit_index >= 32) {
        return -1;
    }

    for (size_t i = 0; i < nitems; ++i) {
        maskArr[i] &= ~(1U << bit_index);
    }

    return 0;
}

int setBits(uint32_t* maskArr, size_t nitems, size_t bit_index) {
    if (bit_index >= 32) {
        return -1;
    }

    for (size_t i = 0; i < nitems; ++i) {
        maskArr[i] |= (1U << bit_index);
    }

    return 0;
}

int checkBits(uint32_t* maskArr, size_t len, size_t bit_index) {
    if (bit_index >= 32) {
        return -1;
    }

    int all_zeros = 1;
    int all_ones = 1;

    for (size_t i = 0; i < len; ++i) {
        if ((maskArr[i] >> bit_index) & 1) {
            all_zeros = 0;
        } else {
            all_ones = 0;
        }

        if (!all_zeros && !all_ones) {
            return -1;
        }
    }

    return all_ones;
}

int main() {
    uint32_t maskArr[] = {0b1010, 0b0101, 0b1100};
    size_t nitems = sizeof(maskArr) / sizeof(maskArr[0]);
    size_t bit_index = 2;

    if (clearBits(maskArr, nitems, bit_index) == 0) {
        printf("Bits cleared:\n");
        for (size_t i = 0; i < nitems; ++i) {
            printf("maskArr[%zu] = %08x\n", i, maskArr[i]);
        }
    } else {
        printf("Error in clearBits\n");
    }

    if (setBits(maskArr, nitems, bit_index) == 0) {
        printf("Bits set:\n");
        for (size_t i = 0; i < nitems; ++i) {
            printf("maskArr[%zu] = %08x\n", i, maskArr[i]);
        }
    } else {
        printf("Error in setBits\n");
    }

    int check_result = checkBits(maskArr, nitems, bit_index);
    if (check_result == 1) {
        printf("All ones for bit index %zu\n", bit_index);
    } else if (check_result == 0) {
        printf("All zeros for bit index %zu\n", bit_index);
    } else {
        printf("Error in checkBits\n");
    }

    return 0;
}
