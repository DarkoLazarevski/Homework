#include <stdio.h>
#include <stdbool.h>

typedef struct {
    unsigned int year: 12;   
    unsigned int month: 4;  
    unsigned int day: 5;     
    unsigned int hour: 5;    
    unsigned int minute: 6;  
    unsigned int second: 6;  
} MyTime;

int isLeapYear(MyTime t) {
   
    return (t.year % 4 == 0 && t.year % 100 != 0) || (t.year % 400 == 0);
}

int totalDaysInYear(MyTime t) {
    return isLeapYear(t) ? 366 : 365;
}

void printMonth(MyTime t) {
    const char *months[] = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };
    
    if (t.month >= 1 && t.month <= 12) {
        printf("%s\n", months[t.month - 1]);
    } else {
        printf("Invalid month\n");
    }
}

int secondsPassed(MyTime t) {
    const int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    int totalSeconds = 0;

    for (int i = 1; i < t.month; i++) {
        totalSeconds += daysInMonth[i];
        if (i == 2 && isLeapYear(t)) {
            totalSeconds++; 
        }
    }
    totalSeconds += t.day - 1;
    totalSeconds = totalSeconds * 24 + t.hour;
    totalSeconds = totalSeconds * 60 + t.minute;
    totalSeconds = totalSeconds * 60 + t.second;

    return totalSeconds;
}
int main() {
    MyTime time = {2023, 8, 14, 12, 30, 45};
    printf("Size of MyTime: %zu bytes\n", sizeof(MyTime));
    printf("Is leap year: %d\n", isLeapYear(time));
    printf("Total days in year: %d\n", totalDaysInYear(time));
    printf("Month: ");
    printMonth(time);
    printf("Seconds passed: %d\n", secondsPassed(time));
    return 0;
}
