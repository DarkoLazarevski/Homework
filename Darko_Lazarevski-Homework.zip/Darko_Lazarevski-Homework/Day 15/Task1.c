#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc == 1) {
        char buffer[4096];
        while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            fputs(buffer, stdout);
        }
    } else {
        for (int i = 1; i < argc; i++) {
            FILE *file = fopen(argv[i], "r");
            if (file == NULL) {
                fprintf(stderr, "Error opening file: %s\n", argv[i]);
                continue;
            }

            char buffer[4096];
            while (fgets(buffer, sizeof(buffer), file) != NULL) {
                fputs(buffer, stdout);
            }

            fclose(file);
        }
    }

    return 0;
}
