#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define COUNT 10 

typedef struct {
    char title[151];
    char author[101];
    int pages;
    double price;
} Book;

void generateRandomString(char *str, int minLen, int maxLen) {
    int len = rand() % (maxLen - minLen + 1) + minLen;
    for (int i = 0; i < len; i++) {
        char randomChar = 'a' + rand() % 26;
        str[i] = randomChar;
    }
    str[len] = '\0';
}

void generateRandomBook(Book *book) {
    generateRandomString(book->title, 10, 20);
    generateRandomString(book->author, 10, 20);
    book->pages = rand() % 1996 + 5; 
    book->price = -1.0 + ((double)rand() / RAND_MAX) * 1001.0; 
}

int compareByTitle(const void *a, const void *b) {
    return strcmp(((const Book *)a)->title, ((const Book *)b)->title);
}

int main() {
    srand(time(NULL));

    Book books[COUNT];

    for (int i = 0; i < COUNT; i++) {
        generateRandomBook(&books[i]);
    }

    qsort(books, COUNT, sizeof(Book), compareByTitle);

    for (int i = 0; i < COUNT; i++) {
        printf("Title: %s\n", books[i].title);
        printf("Author: %s\n", books[i].author);
        printf("Pages: %d\n", books[i].pages);
        printf("Price: %.2lf\n", books[i].price);
        printf("\n");
    }

    return 0;
}
