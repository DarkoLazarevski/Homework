#include<stdio.h>

int main()
{
  float n;
printf("Enter a number = ");
scanf("%f",&n);
 
float i;
float j;
float c;
float max=0;
int a;
int b=1;

for(j = 0; j<=n; j++){
    if(j*j*j==n){
        a=1;
        c=j;
        //printf("%.f", i);
    }
}
for(i = 0; i<=n;i=i+0.0001){
    if(i*i*i<=n && i*i*i>=n-0.05){
        if(max<=i){
            max=i;
        }
}
}
//printf("\n%.4f",max);
if(a-1==0){
    printf("The root is: %.f\n", c);
}
else{
    printf("The root is: %.4f\n",max);
}
}